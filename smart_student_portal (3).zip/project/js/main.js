/* ============================================
   SMART STUDENT PORTAL — Global Script
   ============================================ */

// ─── NAVBAR ────────────────────────────────
const hamburger = document.getElementById('hamburger');
const navLinks  = document.getElementById('navLinks');

if (hamburger && navLinks) {
  hamburger.addEventListener('click', () => {
    navLinks.classList.toggle('open');
    hamburger.setAttribute('aria-expanded', navLinks.classList.contains('open'));
  });

  // Close on link click (mobile)
  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => navLinks.classList.remove('open'));
  });
}

// Mark active nav link
(function () {
  const page = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.navbar-links a').forEach(a => {
    const href = a.getAttribute('href');
    if (href === page || (page === '' && href === 'index.html')) {
      a.classList.add('active');
    }
  });
})();

// ─── TOAST ────────────────────────────────
function showToast(message, type = 'success') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast' + (type === 'error' ? ' error' : '');
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => toast.remove(), 3000);
}

// ─── FORM VALIDATION HELPER ────────────────
function validateField(input, errorEl, rule) {
  const val = input.value.trim();
  const msg = rule(val);
  if (msg) {
    input.style.borderColor = 'var(--danger)';
    if (errorEl) { errorEl.textContent = msg; errorEl.classList.add('show'); }
    return false;
  }
  input.style.borderColor = '';
  if (errorEl) errorEl.classList.remove('show');
  return true;
}

const rules = {
  required: v => v ? '' : 'This field is required.',
  email:    v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? '' : 'Enter a valid email address.',
  phone:    v => /^\d{10}$/.test(v.replace(/[\s\-()]/g,'')) ? '' : 'Enter a valid 10-digit phone number.',
  minLen:   n => v => v.length >= n ? '' : `Minimum ${n} characters required.`,
};
