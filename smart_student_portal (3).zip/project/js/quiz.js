/* ============================================
   QUIZ PAGE SCRIPT
   ============================================ */

const QUESTIONS = [
  {
    category: 'HTML',
    text: 'What does the <canvas> element in HTML5 allow you to do?',
    options: ['Draw graphics via JavaScript', 'Embed audio files', 'Create database connections', 'Define CSS styles'],
    answer: 0,
    explanation: 'The <canvas> element provides an API to draw 2D and 3D graphics using JavaScript.'
  },
  {
    category: 'CSS',
    text: 'Which CSS property creates a flexible box layout container?',
    options: ['display: block', 'display: flex', 'display: grid', 'display: inline'],
    answer: 1,
    explanation: '"display: flex" enables the Flexbox layout model on an element.'
  },
  {
    category: 'JavaScript',
    text: 'Which method adds an element to the END of an array in JavaScript?',
    options: ['push()', 'pop()', 'shift()', 'unshift()'],
    answer: 0,
    explanation: 'Array.push() appends one or more elements to the end of an array and returns the new length.'
  },
  {
    category: 'CSS',
    text: 'What does the CSS box model consist of (from inside out)?',
    options: ['Content → Border → Padding → Margin', 'Content → Padding → Border → Margin', 'Margin → Border → Padding → Content', 'Padding → Content → Border → Margin'],
    answer: 1,
    explanation: 'The CSS box model layers are: Content → Padding → Border → Margin (from inside to outside).'
  },
  {
    category: 'JavaScript',
    text: 'What does DOM stand for?',
    options: ['Document Object Model', 'Data Output Manager', 'Dynamic Object Management', 'Document Output Module'],
    answer: 0,
    explanation: 'DOM stands for Document Object Model — a programming interface for web documents.'
  },
  {
    category: 'HTML',
    text: 'Which HTML5 input type is used for date selection?',
    options: ['type="calendar"', 'type="datetime"', 'type="date"', 'type="time"'],
    answer: 2,
    explanation: 'type="date" creates a date picker. Other valid types include "datetime-local" and "time".'
  },
  {
    category: 'JavaScript',
    text: 'Which method converts a JSON string into a JavaScript object?',
    options: ['JSON.stringify()', 'JSON.parse()', 'JSON.convert()', 'JSON.toObject()'],
    answer: 1,
    explanation: 'JSON.parse() deserializes a JSON string. JSON.stringify() does the reverse.'
  },
  {
    category: 'CSS',
    text: 'Which CSS unit is relative to the viewport width?',
    options: ['em', 'rem', 'vw', 'px'],
    answer: 2,
    explanation: '"vw" (viewport width) represents 1% of the viewport\'s width. "vh" similarly uses height.'
  },
  {
    category: 'HTML',
    text: 'What is the correct way to link an external CSS file in HTML?',
    options: ['<style href="style.css">', '<link rel="stylesheet" href="style.css">', '<css src="style.css">', '<script type="css" src="style.css">'],
    answer: 1,
    explanation: 'The <link> tag with rel="stylesheet" is the standard way to include external CSS files.'
  },
  {
    category: 'JavaScript',
    text: 'What does localStorage.setItem() do?',
    options: ['Reads data from the server', 'Stores data persistently in the browser', 'Creates a session cookie', 'Sends data to an API'],
    answer: 1,
    explanation: 'localStorage stores key-value pairs persistently in the browser even after the window is closed.'
  },
];

// ─── STATE ──────────────────────────────────
let state = {
  screen:      'start',  // start | quiz | result
  current:     0,
  score:        0,
  answered:    null,
  correctCount: 0,
  wrongCount:   0,
  timerVal:    30,
  timerInterval: null,
};

// ─── SCREENS ────────────────────────────────
function show(id) {
  ['quizStart','quizScreen','quizResult'].forEach(s => {
    const el = document.getElementById(s);
    if (el) el.style.display = (s === id) ? 'block' : 'none';
  });
}

// ─── START ───────────────────────────────────
function startQuiz() {
  state.current = 0; state.score = 0;
  state.correctCount = 0; state.wrongCount = 0;
  state.answered = null;
  show('quizScreen');
  renderQuestion();
}

// ─── RENDER QUESTION ────────────────────────
function renderQuestion() {
  clearInterval(state.timerInterval);
  state.answered = null;
  state.timerVal = 30;

  const q = QUESTIONS[state.current];
  const total = QUESTIONS.length;

  // Header
  document.getElementById('qProgress').textContent = `${state.current + 1} / ${total}`;
  document.getElementById('qScore').textContent = `Score: ${state.score}`;
  document.getElementById('progressFill').style.width = ((state.current / total) * 100) + '%';

  // Question
  document.getElementById('qCategory').textContent = q.category;
  document.getElementById('qText').textContent = q.text;

  // Options
  const optList = document.getElementById('optionsList');
  const letters = ['A','B','C','D'];
  optList.innerHTML = q.options.map((opt, i) => `
    <button class="option-btn" onclick="selectOption(${i})" id="opt_${i}">
      <span class="option-letter">${letters[i]}</span>
      <span>${opt}</span>
    </button>`
  ).join('');

  // Explanation
  const expBox = document.getElementById('explanation');
  if (expBox) expBox.classList.remove('show');

  // Next btn
  const nextBtn = document.getElementById('nextBtn');
  if (nextBtn) {
    nextBtn.disabled = true;
    nextBtn.textContent = state.current === total - 1 ? '🏁 Finish Quiz' : 'Next →';
  }

  // Timer
  updateTimer();
  state.timerInterval = setInterval(() => {
    state.timerVal--;
    updateTimer();
    if (state.timerVal <= 0) {
      clearInterval(state.timerInterval);
      if (state.answered === null) autoExpire();
    }
  }, 1000);
}

function updateTimer() {
  const el = document.getElementById('qTimer');
  if (!el) return;
  el.textContent = '⏱ ' + state.timerVal + 's';
  el.className = 'quiz-timer';
  if (state.timerVal <= 10) el.classList.add('warning');
  if (state.timerVal <= 5)  el.classList.add('danger');
}

function autoExpire() {
  if (state.answered !== null) return;
  state.answered = -1;
  state.wrongCount++;
  showAnswers(null);
  if (document.getElementById('nextBtn')) document.getElementById('nextBtn').disabled = false;
}

// ─── SELECT OPTION ──────────────────────────
function selectOption(idx) {
  if (state.answered !== null) return;
  clearInterval(state.timerInterval);
  state.answered = idx;

  const q = QUESTIONS[state.current];
  const correct = (idx === q.answer);

  if (correct) {
    const bonus = Math.ceil(state.timerVal / 5);
    state.score += 10 + bonus;
    state.correctCount++;
  } else {
    state.wrongCount++;
  }

  document.getElementById('qScore').textContent = `Score: ${state.score}`;
  showAnswers(idx);

  const expBox = document.getElementById('explanation');
  if (expBox) {
    expBox.innerHTML = `<strong>${correct ? '✅ Correct!' : '❌ Wrong!'}</strong> ${q.explanation}`;
    expBox.classList.add('show');
  }

  if (document.getElementById('nextBtn')) document.getElementById('nextBtn').disabled = false;
}

function showAnswers(selectedIdx) {
  const q = QUESTIONS[state.current];
  QUESTIONS[state.current].options.forEach((_, i) => {
    const btn = document.getElementById('opt_' + i);
    if (!btn) return;
    btn.disabled = true;
    if (i === q.answer)    btn.classList.add('correct');
    if (i === selectedIdx && i !== q.answer) btn.classList.add('wrong');
  });
}

// ─── NEXT ────────────────────────────────────
function nextQuestion() {
  if (state.current < QUESTIONS.length - 1) {
    state.current++;
    renderQuestion();
  } else {
    showResult();
  }
}

// ─── RESULT ──────────────────────────────────
function showResult() {
  clearInterval(state.timerInterval);
  show('quizResult');

  const total  = QUESTIONS.length;
  const pct    = Math.round((state.correctCount / total) * 100);
  let grade = 'F', msg = '😕 Keep practicing!', color = 'var(--danger)';

  if (pct >= 90) { grade = 'A+'; msg = '🎉 Outstanding! Perfect performance!'; color = 'var(--accent3)'; }
  else if (pct >= 80) { grade = 'A';  msg = '🌟 Excellent work!'; color = 'var(--accent3)'; }
  else if (pct >= 70) { grade = 'B';  msg = '👍 Good job! Room to grow.'; color = 'var(--accent)'; }
  else if (pct >= 60) { grade = 'C';  msg = '😊 Not bad — review weak areas.'; color = 'var(--warning)'; }
  else if (pct >= 50) { grade = 'D';  msg = '📖 Study more and try again!'; color = 'var(--warning)'; }

  document.getElementById('rGrade').textContent   = grade;
  document.getElementById('rGrade').style.color   = color;
  document.getElementById('rMessage').textContent = msg;
  document.getElementById('rScore').textContent   = state.score;
  document.getElementById('rCorrect').textContent = state.correctCount;
  document.getElementById('rWrong').textContent   = state.wrongCount;
  document.getElementById('rPct').textContent     = pct + '%';

  // Animated ring
  const ring = document.getElementById('resultRing');
  if (ring) ring.style.setProperty('--pct', pct + '%');

  const scoreEl = document.getElementById('rScoreRing');
  if (scoreEl) scoreEl.textContent = pct + '%';
}

// ─── INIT ────────────────────────────────────
show('quizStart');
