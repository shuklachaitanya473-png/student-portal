/* ============================================
   TO-DO LIST PAGE SCRIPT
   ============================================ */

let tasks = JSON.parse(localStorage.getItem('ssp_tasks') || '[]');
let currentFilter = 'all';

// ─── SAVE / LOAD ────────────────────────────
function saveTasks() {
  localStorage.setItem('ssp_tasks', JSON.stringify(tasks));
}

// ─── RENDER ─────────────────────────────────
function renderTasks() {
  const list = document.getElementById('taskList');
  if (!list) return;

  let filtered = tasks;
  if (currentFilter === 'active')    filtered = tasks.filter(t => !t.completed);
  if (currentFilter === 'completed') filtered = tasks.filter(t => t.completed);
  if (currentFilter === 'high')      filtered = tasks.filter(t => t.priority === 'high');
  if (currentFilter === 'medium')    filtered = tasks.filter(t => t.priority === 'medium');
  if (currentFilter === 'low')       filtered = tasks.filter(t => t.priority === 'low');

  list.innerHTML = filtered.length === 0
    ? `<div class="empty-state">
         <div class="empty-icon">📋</div>
         <div class="empty-title">No tasks here</div>
         <div class="empty-subtitle">${currentFilter === 'all' ? 'Add your first task above!' : 'Nothing in this filter.'}</div>
       </div>`
    : filtered.map(task => `
        <div class="task-item ${task.completed ? 'completed' : ''}" data-id="${task.id}">
          <button class="task-checkbox ${task.completed ? 'checked' : ''}" onclick="toggleTask('${task.id}')" title="Toggle complete"></button>
          <span class="task-text">${escapeHtml(task.text)}</span>
          <div class="task-meta">
            <div class="priority-dot ${task.priority}"></div>
            <span class="task-date">${formatDate(task.created)}</span>
            <button class="delete-btn" onclick="deleteTask('${task.id}')" title="Delete task">✕</button>
          </div>
        </div>`
    ).join('');

  // Update counter
  const counter = document.getElementById('taskCounter');
  if (counter) counter.textContent = filtered.length;

  updateStats();
}

// ─── STATS ──────────────────────────────────
function updateStats() {
  const total     = tasks.length;
  const done      = tasks.filter(t => t.completed).length;
  const active    = total - done;
  const high      = tasks.filter(t => t.priority === 'high' && !t.completed).length;
  const pct       = total ? Math.round((done / total) * 100) : 0;

  // Ring
  const RADIUS = 44, CIRCUM = 2 * Math.PI * RADIUS;
  const fill = document.querySelector('.ring-fill');
  const pctText = document.querySelector('.ring-pct-text');
  if (fill) fill.style.strokeDashoffset = CIRCUM - (pct / 100) * CIRCUM;
  if (pctText) pctText.textContent = pct + '%';

  setText('statTotal',  total);
  setText('statDone',   done);
  setText('statActive', active);
  setText('statHigh',   high);

  // Set dasharray on load
  if (fill) fill.setAttribute('stroke-dasharray', CIRCUM);
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

// ─── ADD TASK ────────────────────────────────
function addTask() {
  const input    = document.getElementById('taskInput');
  const priority = document.getElementById('taskPriority');
  const text = input.value.trim();

  if (!text) {
    input.focus();
    input.style.borderColor = 'var(--danger)';
    showToast('⚠️ Please enter a task.', 'error');
    return;
  }

  input.style.borderColor = '';
  const task = {
    id:        'task_' + Date.now(),
    text,
    priority:  priority ? priority.value : 'medium',
    completed: false,
    created:   new Date().toISOString(),
  };

  tasks.unshift(task);
  saveTasks();
  renderTasks();
  input.value = '';
  input.focus();
  showToast('✅ Task added!');
}

// ─── TOGGLE ─────────────────────────────────
function toggleTask(id) {
  const task = tasks.find(t => t.id === id);
  if (task) {
    task.completed = !task.completed;
    saveTasks();
    renderTasks();
  }
}

// ─── DELETE ─────────────────────────────────
function deleteTask(id) {
  tasks = tasks.filter(t => t.id !== id);
  saveTasks();
  renderTasks();
  showToast('🗑️ Task removed.');
}

// ─── CLEAR COMPLETED ────────────────────────
function clearCompleted() {
  const count = tasks.filter(t => t.completed).length;
  if (!count) { showToast('Nothing to clear.', 'error'); return; }
  tasks = tasks.filter(t => !t.completed);
  saveTasks();
  renderTasks();
  showToast(`🧹 Cleared ${count} completed task(s).`);
}

// ─── FILTER ─────────────────────────────────
function setFilter(filter) {
  currentFilter = filter;
  document.querySelectorAll('.filter-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.filter === filter);
  });
  renderTasks();
}

// ─── ENTER KEY ──────────────────────────────
document.getElementById('taskInput')?.addEventListener('keydown', e => {
  if (e.key === 'Enter') addTask();
});

// ─── UTILITIES ──────────────────────────────
function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
}

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ─── INIT ────────────────────────────────────
renderTasks();
