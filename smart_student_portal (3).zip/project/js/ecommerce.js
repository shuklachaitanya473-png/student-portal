/* ============================================
   E-COMMERCE PAGE SCRIPT
   ============================================ */

const PRODUCTS = [
  { id:1,  name:'Wireless Noise-Cancelling Headphones', price:4999,  original:7999,  category:'electronics', emoji:'🎧', rating:4.5, reviews:128, badge:'Best Seller' },
  { id:2,  name:'Mechanical Gaming Keyboard',           price:2499,  original:3499,  category:'electronics', emoji:'⌨️', rating:4.3, reviews:87,  badge:'Hot Deal' },
  { id:3,  name:'Ultra-Slim Laptop Stand',              price:1299,  original:1899,  category:'accessories', emoji:'💻', rating:4.7, reviews:203, badge:'Top Rated' },
  { id:4,  name:'Premium Notebook Set (5-pack)',        price:399,   original:null,  category:'stationery',  emoji:'📓', rating:4.2, reviews:56,  badge:null },
  { id:5,  name:'Ergonomic Mouse',                      price:1799,  original:2499,  category:'electronics', emoji:'🖱️', rating:4.6, reviews:145, badge:'Sale' },
  { id:6,  name:'Cable Management Kit',                 price:649,   original:null,  category:'accessories', emoji:'🔌', rating:4.1, reviews:39,  badge:null },
  { id:7,  name:'Desk Organizer Set',                   price:899,   original:1299,  category:'accessories', emoji:'🗂️', rating:4.4, reviews:72,  badge:'New' },
  { id:8,  name:'Study Planner 2025',                   price:349,   original:null,  category:'stationery',  emoji:'📅', rating:4.8, reviews:301, badge:'Popular' },
  { id:9,  name:'USB-C Hub (7-in-1)',                   price:2199,  original:2999,  category:'electronics', emoji:'🔗', rating:4.5, reviews:189, badge:'Deal' },
  { id:10, name:'Highlighter Pack (12 Colors)',          price:299,   original:null,  category:'stationery',  emoji:'🖊️', rating:4.3, reviews:91,  badge:null },
  { id:11, name:'Monitor Light Bar',                    price:1599,  original:2199,  category:'electronics', emoji:'💡', rating:4.6, reviews:167, badge:'Sale' },
  { id:12, name:'Sticky Notes Mega Pack',               price:199,   original:null,  category:'stationery',  emoji:'📌', rating:4.0, reviews:44,  badge:null },
];

let cart         = JSON.parse(localStorage.getItem('ssp_cart') || '[]');
let wishlist     = JSON.parse(localStorage.getItem('ssp_wishlist') || '[]');
let currentUser  = JSON.parse(localStorage.getItem('ssp_user') || 'null');
let currentCat   = 'all';
let searchQuery  = '';

// ─── AUTH ────────────────────────────────────
function checkAuth() {
  if (!currentUser) {
    document.getElementById('loginModal').style.display = 'flex';
    document.getElementById('storeContent').style.display = 'none';
  } else {
    document.getElementById('loginModal').style.display = 'none';
    document.getElementById('storeContent').style.display = 'block';
    document.getElementById('userDisplay').textContent = currentUser.name;
    const av = document.getElementById('userAvatar');
    if (av) av.textContent = currentUser.name.charAt(0).toUpperCase();
    renderProducts();
    renderCart();
  }
}

function login() {
  const email = document.getElementById('loginEmail');
  const pass  = document.getElementById('loginPass');
  const eerr  = document.getElementById('loginEmailErr');
  const perr  = document.getElementById('loginPassErr');
  let valid = true;

  if (!validateField(email, eerr, rules.email))       valid = false;
  if (!validateField(pass,  perr, rules.minLen(6)))   valid = false;

  if (valid) {
    currentUser = { name: email.value.split('@')[0], email: email.value };
    localStorage.setItem('ssp_user', JSON.stringify(currentUser));
    checkAuth();
    showToast('👋 Welcome, ' + currentUser.name + '!');
  }
}

function logout() {
  currentUser = null;
  localStorage.removeItem('ssp_user');
  checkAuth();
}

function switchForm(type) {
  const title = document.getElementById('modalTitle');
  const sub   = document.getElementById('modalSub');
  const btn   = document.getElementById('authBtn');
  const footLink = document.getElementById('footLink');
  const footText = document.getElementById('footText');

  if (type === 'signup') {
    if (title) title.textContent = 'Create Account';
    if (sub)   sub.textContent   = 'Join to start shopping.';
    if (btn)   { btn.textContent = 'Sign Up'; btn.onclick = login; }
    if (footText) footText.textContent = 'Already have an account? ';
    if (footLink) { footLink.textContent = 'Log In'; footLink.onclick = () => switchForm('login'); }
  } else {
    if (title) title.textContent = 'Welcome Back';
    if (sub)   sub.textContent   = 'Log in to continue shopping.';
    if (btn)   { btn.textContent = 'Log In'; btn.onclick = login; }
    if (footText) footText.textContent = "Don't have an account? ";
    if (footLink) { footLink.textContent = 'Sign Up'; footLink.onclick = () => switchForm('signup'); }
  }
}

// ─── RENDER PRODUCTS ────────────────────────
function renderProducts() {
  const grid = document.getElementById('productsGrid');
  if (!grid) return;

  let list = PRODUCTS;
  if (currentCat !== 'all') list = list.filter(p => p.category === currentCat);
  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    list = list.filter(p => p.name.toLowerCase().includes(q) || p.category.includes(q));
  }

  if (!list.length) {
    grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:3rem;color:var(--text-muted);">
      <div style="font-size:2rem">🔍</div>
      <div style="margin-top:0.5rem">No products found.</div>
    </div>`;
    return;
  }

  grid.innerHTML = list.map(p => {
    const inCart    = cart.some(c => c.id === p.id);
    const inWish    = wishlist.includes(p.id);
    const stars     = '★'.repeat(Math.floor(p.rating)) + (p.rating % 1 ? '½' : '');
    const priceDisp = p.original
      ? `<span class="original">₹${p.original.toLocaleString()}</span> ₹${p.price.toLocaleString()}`
      : `₹${p.price.toLocaleString()}`;

    return `
    <div class="product-card" data-id="${p.id}">
      <div class="product-image-wrap">
        ${p.badge ? `<span class="product-badge-corner badge badge-blue">${p.badge}</span>` : ''}
        <button class="product-wishlist ${inWish?'active':''}" onclick="toggleWishlist(${p.id},event)" title="Wishlist">${inWish?'❤️':'🤍'}</button>
        <span style="position:relative;z-index:1">${p.emoji}</span>
      </div>
      <div class="product-info">
        <div class="product-category">${p.category}</div>
        <div class="product-name">${p.name}</div>
        <div class="product-rating">
          <span class="stars">${stars}</span>
          <span>${p.rating} (${p.reviews})</span>
        </div>
        <div class="product-footer">
          <div class="product-price">${priceDisp}</div>
          <button class="add-cart-btn ${inCart?'added':''}" onclick="addToCart(${p.id},event)" title="${inCart?'In cart':'Add to cart'}">${inCart?'✓':'+'}</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

// ─── CART ────────────────────────────────────
function addToCart(id, e) {
  if (e) e.stopPropagation();
  const existing = cart.find(c => c.id === id);
  if (existing) {
    existing.qty++;
  } else {
    const p = PRODUCTS.find(p => p.id === id);
    cart.push({ id, name: p.name, price: p.price, emoji: p.emoji, qty: 1 });
  }
  saveCart();
  renderProducts();
  renderCart();
  showToast('🛒 Added to cart!');
}

function removeFromCart(id) {
  cart = cart.filter(c => c.id !== id);
  saveCart();
  renderCart();
  renderProducts();
}

function changeQty(id, delta) {
  const item = cart.find(c => c.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) { removeFromCart(id); return; }
  saveCart();
  renderCart();
}

function saveCart() {
  localStorage.setItem('ssp_cart', JSON.stringify(cart));
  // Update FAB badge
  const badge = document.getElementById('cartCount');
  if (badge) {
    const total = cart.reduce((s,i) => s + i.qty, 0);
    badge.textContent = total;
    badge.style.display = total ? 'flex' : 'none';
  }
}

function renderCart() {
  const itemsEl = document.getElementById('cartItems');
  if (!itemsEl) return;

  if (!cart.length) {
    itemsEl.innerHTML = `<div class="empty-state"><div class="empty-icon">🛒</div><div class="empty-title">Cart is empty</div><div class="empty-subtitle">Add some products!</div></div>`;
  } else {
    itemsEl.innerHTML = cart.map(item => `
      <div class="cart-item">
        <div class="cart-item-emoji">${item.emoji}</div>
        <div class="cart-item-info">
          <div class="cart-item-name">${item.name}</div>
          <div class="cart-item-price">₹${(item.price * item.qty).toLocaleString()}</div>
        </div>
        <div class="cart-qty">
          <button class="qty-btn" onclick="changeQty(${item.id},-1)">−</button>
          <span class="qty-num">${item.qty}</span>
          <button class="qty-btn" onclick="changeQty(${item.id},1)">+</button>
        </div>
        <button class="btn btn-danger" style="padding:0.3rem 0.6rem;font-size:0.75rem" onclick="removeFromCart(${item.id})">✕</button>
      </div>`
    ).join('');
  }

  const total = cart.reduce((s,i) => s + i.price * i.qty, 0);
  const el = document.getElementById('cartTotal');
  if (el) el.textContent = '₹' + total.toLocaleString();

  saveCart();
}

function checkout() {
  if (!cart.length) { showToast('Your cart is empty!', 'error'); return; }
  cart = [];
  saveCart();
  renderCart();
  renderProducts();
  closeCart();
  showToast('🎉 Order placed successfully!');
}

// ─── CART DRAWER ────────────────────────────
function openCart()  { document.getElementById('cartDrawer').classList.add('open'); document.getElementById('drawerOverlay').classList.add('show'); }
function closeCart() { document.getElementById('cartDrawer').classList.remove('open'); document.getElementById('drawerOverlay').classList.remove('show'); }

// ─── WISHLIST ───────────────────────────────
function toggleWishlist(id, e) {
  if (e) e.stopPropagation();
  if (wishlist.includes(id)) {
    wishlist = wishlist.filter(w => w !== id);
    showToast('💔 Removed from wishlist.');
  } else {
    wishlist.push(id);
    showToast('❤️ Added to wishlist!');
  }
  localStorage.setItem('ssp_wishlist', JSON.stringify(wishlist));
  renderProducts();
}

// ─── FILTER / SEARCH ────────────────────────
function setCategory(cat) {
  currentCat = cat;
  document.querySelectorAll('.cat-pill').forEach(p => p.classList.toggle('active', p.dataset.cat === cat));
  renderProducts();
}

document.getElementById('searchInput')?.addEventListener('input', e => {
  searchQuery = e.target.value.trim();
  renderProducts();
});

// ─── INIT ────────────────────────────────────
checkAuth();
