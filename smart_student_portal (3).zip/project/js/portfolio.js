/* ============================================
   PORTFOLIO PAGE SCRIPT
   ============================================ */

// ─── ANIMATE SKILL BARS ON SCROLL ──────────
function animateSkillBars() {
  const bars = document.querySelectorAll('.skill-bar');
  bars.forEach(bar => {
    const pct = bar.dataset.pct || '70';
    bar.style.width = pct + '%';
  });
}

// Use IntersectionObserver for skill bars
const skillSection = document.querySelector('.skills-section');
if (skillSection) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { animateSkillBars(); observer.disconnect(); } });
  }, { threshold: 0.2 });
  observer.observe(skillSection);
}

// ─── CONTACT FORM ───────────────────────────
const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', function (e) {
    e.preventDefault();
    let valid = true;

    const fields = [
      { id: 'cf-name',    errId: 'err-name',    rule: rules.required },
      { id: 'cf-email',   errId: 'err-email',   rule: rules.email },
      { id: 'cf-subject', errId: 'err-subject',  rule: rules.required },
      { id: 'cf-message', errId: 'err-message',  rule: rules.required },
    ];

    fields.forEach(f => {
      const input = document.getElementById(f.id);
      const errEl = document.getElementById(f.errId);
      if (!validateField(input, errEl, f.rule)) valid = false;
    });

    if (valid) {
      showToast('✅ Message sent! I\'ll get back to you soon.');
      contactForm.reset();
    }
  });

  // Live validation
  contactForm.querySelectorAll('.input').forEach(input => {
    input.addEventListener('input', () => {
      input.style.borderColor = '';
      const errEl = input.nextElementSibling;
      if (errEl && errEl.classList.contains('form-error')) errEl.classList.remove('show');
    });
  });
}
